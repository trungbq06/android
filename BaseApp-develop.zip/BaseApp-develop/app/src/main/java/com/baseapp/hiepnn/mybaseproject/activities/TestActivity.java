package com.baseapp.hiepnn.mybaseproject.activities;

import com.baseapp.hiepnn.mybaseproject.R;

/**
 * Created by hiepn on 11/05/2017.
 */

public class TestActivity extends BaseActivity {
    @Override
    public int setContentViewId() {
        return R.layout.activity_main;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
