package com.baseapp.hiepnn.mybaseproject.callback;

/**
 * Created by Envy 15T on 9/21/2015.
 */
public interface OnHeaderIconClickListener {
    void onHeaderBack();

    void onHeaderClose();

    void onHeaderSetting();

    void onHeaderEdit();

    void onHeaderSearch();

    void onHeaderConfirm();

    void onHeaderDelete();
}
