package com.baseapp.hiepnn.mybaseproject.callback;

/**
 * Created by V4-OS01 on 14/10/2016.
 */

public interface OnFillBackgroundListener {

    void onFillBackground(String nameTable);
}
