package com.baseapp.hiepnn.mybaseproject.api.volley.bean;

/**
 * Created by Envy 15T on 6/5/2015.
 */
public class ErrorMessage {
    public String message;
}
