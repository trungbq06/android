package com.baseapp.hiepnn.mybaseproject.api.response;

/**
 * Created by User on 9/30/2015.
 */
public class SimpleResponse extends ObjectResponse<String> {
}
