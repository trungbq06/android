package com.baseapp.hiepnn.mybaseproject.api.response;

/**
 * Created by User on 9/29/2015.
 */
public class ObjectResponse<T> extends BaseResponse {

    public T data;
}
