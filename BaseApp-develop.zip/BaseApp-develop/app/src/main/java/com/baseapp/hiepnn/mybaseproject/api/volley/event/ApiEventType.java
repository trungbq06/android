package com.baseapp.hiepnn.mybaseproject.api.volley.event;

/**
 * Created by Envy 15T on 9/24/2015.
 */
public enum ApiEventType {
    SHOW_API_ERROR_DIALOG,
    SHOW_API_TIMEOUT_DIALOG,
    SHOW_API_NO_CONNECTION_DIALOG
}
