package com.baseapp.hiepnn.mybaseproject.api.response;

/**
 * Created by User on 9/30/2015.
 */
public class CheckUserExistBean {
    public String accessToken;
    public String email;
}
