package com.baseapp.hiepnn.mybaseproject.api.volley.callback;

/**
 * Created by User on 9/29/2015.
 */
public interface SimpleRequestCallBack {
    void onResponse(boolean success, String message);
}
