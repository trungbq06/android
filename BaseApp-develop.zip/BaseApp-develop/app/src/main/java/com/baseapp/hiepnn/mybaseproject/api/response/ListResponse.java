package com.baseapp.hiepnn.mybaseproject.api.response;

import java.util.List;

/**
 * Created by User on 9/29/2015.
 */
public class ListResponse<T> extends BaseResponse {
    public List<T> data;
}
